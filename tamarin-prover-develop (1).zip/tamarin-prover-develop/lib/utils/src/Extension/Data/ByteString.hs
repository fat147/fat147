-- |
-- Copyright   : (c) 2012 Benedikt Schmidt
-- License     : GPL v3 (see LICENSE)
--
-- Maintainer  : Benedikt Schmidt <beschmi@gmail.com>
--
-- Provided NFData instance for ByteString (with bytestring < 0.10)
module Extension.Data.ByteString (
  ) where

import Data.ByteString ()
