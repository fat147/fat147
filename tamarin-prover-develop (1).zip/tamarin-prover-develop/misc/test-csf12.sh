#!/bin/sh

./averages.py --passes=10 "../examples/csf12/*.spthy"
